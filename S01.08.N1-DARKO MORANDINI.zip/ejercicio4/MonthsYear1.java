package ejercicio4;

@FunctionalInterface
public interface MonthsYear1 {

	public void meses(); 
}
