package ejercicio4;

import java.util.ArrayList;

public class App3 {

	public static void main(String[] args) {
	
		MonthsYear1 instancia = ()-> {	 
			ArrayList<String> listaMeses = new ArrayList<String>();
			listaMeses.add("Enero");
			listaMeses.add("Febrero");
			listaMeses.add("Marzo");
			listaMeses.add("Abril");
			listaMeses.add("Mayo");
			listaMeses.add("Junio");
			listaMeses.add("Julio");
			listaMeses.add("Agosto");
			listaMeses.add("Septiembre");
			listaMeses.add("Octubre");
			listaMeses.add("Noviembre");
			listaMeses.add("Diciembre");		

			//método reference, más conciso
			listaMeses.forEach(System.out::println);	
		};
		
		instancia.meses();
	}

}