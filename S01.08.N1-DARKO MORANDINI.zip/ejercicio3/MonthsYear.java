package ejercicio3;

@FunctionalInterface
public interface MonthsYear {

	public void meses(); 
}
