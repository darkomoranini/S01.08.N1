package ejercicio7;

@FunctionalInterface
public interface Nombres1 {

	public void nombres();
}
