package ejercicio2;

import java.util.ArrayList;

@FunctionalInterface
public interface PalabrasConO1 {

	public ArrayList<String> arrayPalabrasConO1(ArrayList<String>palabras); 
	  
	 
	
}