package ejercicio2;

import java.util.ArrayList;

public class App1 {
    public static void main(String[] args) {
        ArrayList<String> palabras = new ArrayList<String>();
        palabras.add("hola");
        palabras.add("adios");
        palabras.add("bienvenido");
        palabras.add("ciao");
       
        PalabrasConO1 arrayPalabrasConO1 = s -> {
            ArrayList<String> result = new ArrayList<String>();
            for (String palabra : palabras) {
                if (palabra.contains("o") && palabra.length()>5) {
                    result.add(palabra);
                }
            }
            return result;
        };
       
        System.out.println(arrayPalabrasConO1.arrayPalabrasConO1(palabras));
    }
}


