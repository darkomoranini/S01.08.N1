package ejercicio5;

public class App4 {

	public static void main(String[] args) {
		
		PiValue instancia =() -> {		
			return 3.1415;
		};
		System.out.println(instancia.getPiValue());
	}
}

