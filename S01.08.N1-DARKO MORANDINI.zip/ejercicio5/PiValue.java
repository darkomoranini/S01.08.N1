package ejercicio5;

@FunctionalInterface
public interface PiValue {

	public double getPiValue();
}
