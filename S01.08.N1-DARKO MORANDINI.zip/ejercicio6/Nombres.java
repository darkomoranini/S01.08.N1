package ejercicio6;

@FunctionalInterface
public interface Nombres {

	public void nombres();
}
