package ejercicio6;
import java.util.*;

public class App5 {

	public static void main(String[] args) {
		
		Nombres instanciaNombres = () -> {
			
		ArrayList<Object>listaNombres = new ArrayList<Object>();
		listaNombres.add("Esto es una cadena de strings");
		listaNombres.add("una cadena mas corta");
		listaNombres.add("palabra");
		listaNombres.add(12);
		
		listaNombres.sort(Comparator.comparingInt(o -> o.toString().length()));
		
		System.out.println(listaNombres);
		};
		
		instanciaNombres.nombres();
	}
}
