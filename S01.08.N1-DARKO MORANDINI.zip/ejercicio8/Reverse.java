package ejercicio8;

@FunctionalInterface
public interface Reverse {

	public String reverse(String palabra);

}
