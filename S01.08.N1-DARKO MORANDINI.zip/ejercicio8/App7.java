package ejercicio8;

public class App7 {

	public static void main(String[] args) {
		
		
		Reverse instancia = (palabra) -> {
		
			//StringBuilder reverse = new StringBuilder(palabra).reverse();
			String reverse="";
			for(int i=palabra.length()-1; i>=0; i--) {
				reverse+=palabra.charAt(i);
			}
			//return reverse.toString();
			return reverse;
		};
		
		System.out.println(instancia.reverse("cielo"));
		
	}
}
