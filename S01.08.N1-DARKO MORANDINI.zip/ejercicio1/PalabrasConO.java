package ejercicio1;

import java.util.ArrayList;

@FunctionalInterface
public interface PalabrasConO {

	ArrayList<String> arrayPalabrasConO(ArrayList<String>palabras); 
	  
	 
	
}
