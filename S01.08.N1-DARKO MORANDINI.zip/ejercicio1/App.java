package ejercicio1;
import java.util.*;
public class App {
    public static void main(String[] args) {
        ArrayList<String> palabras = new ArrayList<String>();
        palabras.add("hola");
        palabras.add("adios");
        palabras.add("bienvenido");
        palabras.add("ciao");
       
        PalabrasConO arrayPalabrasConO = s -> {
            ArrayList<String> result = new ArrayList<String>();
            for (String palabra : palabras) {
                if (palabra.contains("o")) {
                    result.add(palabra);
                }
            }
            return result;
        };
       
        System.out.println(arrayPalabrasConO.arrayPalabrasConO(palabras));
    }
}

